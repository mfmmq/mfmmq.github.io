﻿using System;

namespace Exercise5
{
	public class Academia
	{
		public Academia ()
		{
		}
	}
}

