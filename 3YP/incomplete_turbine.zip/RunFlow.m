%RunFlow

% Import gas table structures
load('NH3.mat');
load('O2.mat');
load('N2.mat');
load('H2O.mat');
load('NO.mat');
load('H2.mat');