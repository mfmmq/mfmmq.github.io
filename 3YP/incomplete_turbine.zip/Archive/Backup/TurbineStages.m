%TurbineStages.m

% Define the number of stages in the turbine
Stages = 10;

% Define the stage parameters
% For simplicity, assume all stage blades have same angles
